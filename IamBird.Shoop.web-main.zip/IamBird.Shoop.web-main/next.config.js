/** @type {import('next').NextConfig} */
const nextConfig = {
  reactCompiler: true
};

export default nextConfig;
